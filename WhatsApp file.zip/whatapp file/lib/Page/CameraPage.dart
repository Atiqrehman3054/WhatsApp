import 'package:flutter/material.dart';
import 'package:whatapp/screens/CameraScreen.dart';


class CameraPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return CameraScreen();
  }
}
